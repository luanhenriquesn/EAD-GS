﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;

namespace Spare.ViewModels
{
    public class Select
    {
        public static implicit operator Select(SelectList v)
        {
            throw new NotImplementedException();
        }
    }
}