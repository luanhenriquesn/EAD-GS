﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Spare.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Spare.ViewModels
{
    public class UsuarioViewModel
    {

        public Usuario Usuario { get; set; }

        public SelectList Perfis { get; set; }

    }
}
