﻿using Microsoft.AspNetCore.Mvc;
using Spare.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Spare.ViewModels
{
    public class PerfilViewModel {

        public Perfil Perfil { get; set; }

        public IList<Perfil> Lista { get; set; }

    }
}
