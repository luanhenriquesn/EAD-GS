﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Spare.Models;
using Spare.Repositories;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Spare.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private IUsuarioRepository _usuarioRepository;
        private IDicaRepository _dicaRepository;

        public HomeController(ILogger<HomeController> logger, IUsuarioRepository usuarioRepository, IDicaRepository dicaRepository)
        {
            _logger = logger;
            _usuarioRepository = usuarioRepository;
            _dicaRepository = dicaRepository;
        }

        public IActionResult Index()
        {
            ViewData["quantidadeUsuarios"] = _usuarioRepository.Listar().Count();
            ViewData["quantidadeDicas"] = _dicaRepository.Listar().Count();
            return View();

        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
