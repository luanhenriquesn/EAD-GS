﻿using Microsoft.AspNetCore.Mvc;
using Spare.Models;
using Spare.Repositories;
using Spare.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Spare.Controllers
{
    public class PerfilController : Controller
    {

        private IPerfilRepository _perfilRepository;


        public PerfilController(IPerfilRepository perfilRepository)
        {
            _perfilRepository = perfilRepository;
        }



        private PerfilViewModel CarregarViewModel()
        {
            return new PerfilViewModel()
            {
                Lista = _perfilRepository.Listar()
            };
        }



        public IActionResult Index()
        {
            return View(CarregarViewModel());
        }



        //-----------------------------------------

        [HttpPost]
        public IActionResult Cadastrar(Perfil perfil)
        {
            if (ModelState.IsValid)
            {
                _perfilRepository.Cadastrar(perfil);
                _perfilRepository.Salvar();
                TempData["msg"] = "Perfil Registrado !!!";
                return RedirectToAction("Index");
            }

            
            return View("Index", CarregarViewModel());

        }


        [HttpPost]
        public IActionResult Remover(int id)
        {
            _perfilRepository.Remover(id);
            _perfilRepository.Salvar();
            TempData["msg"] = "Perfil Removido com SUCESSO !!!";
            return RedirectToAction("Index");

        }


    }
}
