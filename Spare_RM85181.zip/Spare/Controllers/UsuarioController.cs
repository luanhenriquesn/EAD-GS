﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Spare.Models;
using Spare.Repositories;
using Spare.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Spare.Controllers
{
    public class UsuarioController : Controller
    {

        private IUsuarioRepository _usuarioRepository;
        private IPerfilRepository _perfilRepository;

        public UsuarioController(IUsuarioRepository usuarioRepository, IPerfilRepository perfilRepository)
        {
            _usuarioRepository = usuarioRepository;
            _perfilRepository = perfilRepository;
        }





        //---------------------------------------------------------------

        [HttpGet]
        public IActionResult Index()
        {
            List<Usuario> usuarios = _usuarioRepository.Listar();
            return View(usuarios);
        }



        private UsuarioViewModel CarregarViewModel(Usuario? usuario)
        {

            return new UsuarioViewModel()
            {
                Usuario = usuario,
                Perfis = new SelectList(_perfilRepository.Listar(), "PerfilId", "Nome")
            };
        }

        //-----------------------------------------

        [HttpGet]
        public IActionResult Cadastrar()
        {
            
            return View(CarregarViewModel(null));
        }



        [HttpPost]
        public IActionResult Cadastrar(Usuario usuario)
        {
            if (ModelState.IsValid)
            {
                _usuarioRepository.Cadastrar(usuario);
                _usuarioRepository.Salvar();
                TempData["msg"] = "Usuário Cadastrado com SUCESSO !!!";
                return RedirectToAction("Index");
            }

            //Como vamos retornar para a página cadastrar, carregamos o GET cadastrar.
            return Cadastrar();

        }

        //----------------------------------------

        [HttpGet]
        public IActionResult Editar(int id)
        {
            Usuario usuario = _usuarioRepository.BuscarPorId(id);
            return View(CarregarViewModel(usuario));
        }


        [HttpPost]
        public IActionResult Editar(Usuario usuario)
        {

            if (ModelState.IsValid)
            {
                _usuarioRepository.Atualizar(usuario);
                _usuarioRepository.Salvar();
                TempData["msg"] = "Usuário Editado com SUCESSO !!!";
                return RedirectToAction("Index");
            }

            //Como vamos retornar para a página editar, carregamos o GET editar, passando o parametro que ele necessita
            return Editar(usuario.UsuarioId);

        }

        //-------------------------------------

        [HttpPost]
        public IActionResult Remover(int id)
        {
            _usuarioRepository.Remover(id);
            _usuarioRepository.Salvar();
            TempData["msg"] = "Usuário Removido com SUCESSO !!!";
            return RedirectToAction("Index");
        }
       

    }
}
