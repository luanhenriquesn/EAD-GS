﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Spare.Models;
using Spare.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Spare.Controllers
{
    public class DicaController : Controller
    {

        private IDicaRepository _dicaRepository;
        private IUsuarioRepository _usuarioRepository;

        public DicaController(IDicaRepository dicaRepository, IUsuarioRepository usuarioRepository)
        {
            _dicaRepository = dicaRepository;
            _usuarioRepository = usuarioRepository;
        }



        //---------------------------------------------------------------

        [HttpGet]
        public IActionResult Index()
        {
            List<Dica> dicas = _dicaRepository.Listar();
            return View(dicas);
        }

        private void CarregarUsuarios()
        {
            List<Usuario> usuarios = _usuarioRepository.Listar();
            ViewBag.usuarios = new SelectList(usuarios, "UsuarioId", "Nome");
        }


        [HttpGet]
        public IActionResult Cadastrar()
        {
            CarregarUsuarios();
            return View();
        }



        [HttpPost]
        public IActionResult Cadastrar(Dica dica)
        {
            if (ModelState.IsValid)
            {
                _dicaRepository.Cadastrar(dica);
                _dicaRepository.Salvar();
                TempData["msg"] = "Dica Cadastrada com SUCESSO !!!";
                return RedirectToAction("Index");
            }

            //Como vamos retornar para a página cadastrar, carregamos o GET cadastrar.
            return Cadastrar();

        }

        //----------------------------------------

        [HttpGet]
        public IActionResult Editar(int id)
        {
            Dica dica = _dicaRepository.BuscarPorId(id);
            CarregarUsuarios();
            return View(dica);
        }


        [HttpPost]
        public IActionResult Editar(Dica dica)
        {

            if (ModelState.IsValid)
            {
                _dicaRepository.Atualizar(dica);
                _dicaRepository.Salvar();
                TempData["msg"] = "Dica Editada com SUCESSO !!!";
                return RedirectToAction("Index");
            }

            //Como vamos retornar para a página editar, carregamos o GET editar, passando o parametro que ele necessita
            return Editar(dica.DicaId);

        }

        //-------------------------------------

        [HttpPost]
        public IActionResult Remover(int id)
        {
            _dicaRepository.Remover(id);
            _dicaRepository.Salvar();
            TempData["msg"] = "Dica Removida com SUCESSO !!!";
            return RedirectToAction("Index");
        }

    }
}
