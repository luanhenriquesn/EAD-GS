﻿using Spare.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Spare.Repositories
{
    public interface IPerfilRepository
    {

        void Cadastrar(Perfil perfil);

        void Remover(int id);

        List<Perfil> Listar();

        void Salvar();


    }
}
