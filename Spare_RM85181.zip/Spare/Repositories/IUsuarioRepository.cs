﻿using Spare.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Spare.Repositories
{
    public interface IUsuarioRepository
    {

        void Cadastrar(Usuario usuario);

        void Atualizar(Usuario usuario);

        void Remover(int id);

        Usuario BuscarPorId(int id);

        List<Usuario> Listar();

        void Salvar();

    }
}
