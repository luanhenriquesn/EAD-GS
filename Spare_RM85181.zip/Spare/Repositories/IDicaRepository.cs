﻿using Spare.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Spare.Repositories
{
    public interface IDicaRepository
    {

        void Cadastrar(Dica dica);

        void Atualizar(Dica dica);

        void Remover(int id);

        Dica BuscarPorId(int id);

        List<Dica> Listar();

        void Salvar();

    }
}
