﻿using Microsoft.EntityFrameworkCore;
using Spare.Models;
using Spare.Persistencia;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Spare.Repositories
{
    public class PerfilRepository : IPerfilRepository
    {

        private SpareContext _context;


        public PerfilRepository(SpareContext context)
        {
            _context = context;
        }



        public void Cadastrar(Perfil perfil)
        {
            _context.Perfis.Add(perfil);
        }

        public List<Perfil> Listar()
        {
            return _context.Perfis.Include(p => p.Usuarios).ToList();
        }

        public void Remover(int id)
        {
            Perfil perfil = _context.Perfis.Find(id);
            _context.Perfis.Remove(perfil);
        }

        public void Salvar()
        {
            _context.SaveChanges();
        }
    }
}
