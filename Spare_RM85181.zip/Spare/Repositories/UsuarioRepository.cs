﻿using Microsoft.EntityFrameworkCore;
using Spare.Models;
using Spare.Persistencia;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Spare.Repositories
{
    public class UsuarioRepository : IUsuarioRepository
    {

        private SpareContext _context;


        public UsuarioRepository(SpareContext context)
        {
            _context = context;
        }



        public void Atualizar(Usuario usuario)
        {
            _context.Usuarios.Update(usuario);
        }

        public Usuario BuscarPorId(int id)
        {
            return _context.Usuarios.Include(u => u.Perfil).Include(u => u.Dicas).Where(u => u.UsuarioId == id).FirstOrDefault();
        }

        public void Cadastrar(Usuario usuario)
        {
            _context.Usuarios.Add(usuario);
        }

        public List<Usuario> Listar()
        {
            return _context.Usuarios.Include(u => u.Perfil).Include(u => u.Dicas).ToList();
        }

        public void Remover(int id)
        {
            Usuario usuario = _context.Usuarios.Find(id);
            _context.Usuarios.Remove(usuario);
        }

        public void Salvar()
        {
            _context.SaveChanges();
        }
    }
}
