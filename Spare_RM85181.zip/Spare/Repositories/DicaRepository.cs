﻿using Microsoft.EntityFrameworkCore;
using Spare.Models;
using Spare.Persistencia;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Spare.Repositories
{
    public class DicaRepository : IDicaRepository
    {

        private SpareContext _context;


        public DicaRepository(SpareContext context)
        {
            _context = context;
        }



        public void Atualizar(Dica dica)
        {
            _context.Dicas.Update(dica);
        }

        public Dica BuscarPorId(int id)
        {
            return _context.Dicas.Include(d => d.Usuario).Where(d => d.DicaId == id).FirstOrDefault();
        }

        public void Cadastrar(Dica dica)
        {
            _context.Dicas.Add(dica);
        }

        public List<Dica> Listar()
        {
            return _context.Dicas.Include(d => d.Usuario).ToList();
        }

        public void Remover(int id)
        {
            Dica dica = _context.Dicas.Find(id);
            _context.Dicas.Remove(dica);
        }

        public void Salvar()
        {
            _context.SaveChanges();
        }
    }
}
