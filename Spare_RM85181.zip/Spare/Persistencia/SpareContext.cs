﻿using Microsoft.EntityFrameworkCore;
using Spare.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Spare.Persistencia
{
    public class SpareContext : DbContext
    {

        //Propriedades que representam os conjuntos do model no banco de dados
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Dica> Dicas { get; set; }
        public DbSet<Perfil> Perfis { get; set; }


        //Construtor que recebe a string de conexão e outras opções
        public SpareContext(DbContextOptions op) : base(op) { }



    }
}
