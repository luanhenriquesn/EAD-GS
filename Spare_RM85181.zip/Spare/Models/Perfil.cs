﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Spare.Models
{
    [Table("TB_PERFIL")]
    public class Perfil
    {

        [Column("Id"), HiddenInput]
        public int PerfilId { get; set; }

        [Required(ErrorMessage = "O nome é obrigatório"), StringLength(20, MinimumLength = 3, ErrorMessage = "O nome deve conter entre 3 e 20 caracteres")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "A descrição é obrigatória"), StringLength(80, MinimumLength = 5, ErrorMessage = "A descrição deve conter entre 5 e 80 caracteres")]
        public string Descricao { get; set; }

        //1:N
        public IList<Usuario> Usuarios { get; set; }

    }
}
