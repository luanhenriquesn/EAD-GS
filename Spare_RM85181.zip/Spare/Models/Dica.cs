﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Spare.Models
{
    [Table("TB_DICA")]
    public class Dica
    {

        [Column("Id"), HiddenInput]
        public int DicaId { get; set; }

        [Required(ErrorMessage = "O título é obrigatório"), StringLength(30, MinimumLength = 4, ErrorMessage = "O título deve conter entre 4 e 30 caracteres")]
        public string Titulo { get; set; }

        [Required(ErrorMessage = "A descrição é obrigatória"), StringLength(2000, MinimumLength = 10, ErrorMessage = "A descrição deve conter entre 10 e 2000 caracteres")]
        public string Descricao { get; set; }



        //N:1
        public Usuario Usuario { get; set; }
        public int UsuarioId { get; set; }


    }
}
