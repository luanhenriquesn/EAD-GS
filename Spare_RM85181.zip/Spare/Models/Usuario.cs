﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Spare.Models
{   
    [Table("TB_USUARIO")]
    public class Usuario
    {

        [Column("Id"), HiddenInput]
        public int UsuarioId { get; set; }

        [Required(ErrorMessage = "O nome é obrigatório"), StringLength(50, MinimumLength = 5, ErrorMessage = "O nome deve conter entre 5 e 50 caracteres")]
        public string Nome { get; set; }

        [ DataType(DataType.EmailAddress), Required(ErrorMessage = "O e-mail é obrigatório"), StringLength(80, MinimumLength = 8, ErrorMessage = "O e-mail deve conter entre 8 e 80 caracteres"), Display(Name = "E-mail")]
        public string Email { get; set; }

        [DataType(DataType.Password), Required(ErrorMessage = "A senha é obrigatória"), StringLength(30, MinimumLength = 5, ErrorMessage = "A senha deve conter entre 5 e 30 caracteres")]
        public string Senha { get; set; }



        //Relacionamentos:

        //N:1
        public Perfil Perfil { get; set; }
        public int PerfilId { get; set; }

        //1:N
        public ICollection<Dica> Dicas { get; set; }

    }
}
